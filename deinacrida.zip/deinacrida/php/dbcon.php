<?php

$con = mysqli_connect("localhost","root","1234","deinacridadb");

if(!$con){
    die('Conexion fallida'. mysqli_connect_error());
}

?>