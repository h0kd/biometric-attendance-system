<?php
require 'dbcon.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Recupera los datos del formulario
    $nombre = $_POST["nombre"];
    $asistencias = $_POST["asistencias"];
    $diasTotales = $_POST["diasTotales"];
    $porcentajeTotal = $_POST["porcentajeTotal"];

    // Realiza la inserción en la base de datos

    if ($con -> connect_error) {
        die("Conexion fallida:". $con -> connect_error);
    }

    $sql = "INSERT INTO estudiante (nombre, asistencias, dias_totales, porcentaje_total) VALUES ('$nombre', $asistencias, $diasTotales, $porcentajeTotal)";
    $result = $con -> query($sql);

    if ($result) {
        // Recupera el último ID insertado
        $estudianteID = mysqli_insert_id($con);

        // Recupera los datos recién insertados para enviarlos al cliente
        $sql2 = "SELECT * FROM estudiante WHERE id = $estudianteID";
        $result2 = $con -> query($sql2);
        $nuevoEstudiante = $result2 -> fetch_assoc();

        // Devuelve los datos como respuesta JSON
        echo json_encode($nuevoEstudiante);
    } else {
        // Manejo de errores, si es necesario
        echo json_encode(array("error" => "Ocurrió un error en la inserción"));
    }

    $con -> close();
}
?>
